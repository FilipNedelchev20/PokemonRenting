﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PokemonRenting.Models.Constants
{
    public class EntityConstants
    {
        public const string Pass = "0123456789";


        public const int FullNameMaxLenght = 50;
        public const int AddressMaxLenght = 100;
    }
}
